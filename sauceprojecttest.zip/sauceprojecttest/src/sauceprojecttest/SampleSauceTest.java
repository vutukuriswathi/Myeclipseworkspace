package sauceprojecttest;


	
	import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

	public class SampleSauceTest {

	  public static final String USERNAME = "swathi_gunuputi";
	  public static final String ACCESS_KEY = "2676a801-c8a2-4611-a294-82c85e411d88";
	  public static final String URL = "http://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub";

	  public static void main(String[] args) throws Exception {

	    DesiredCapabilities caps = DesiredCapabilities.chrome();
	    caps.setCapability("platform", "Windows XP");
	    caps.setCapability("version", "43.0");

	    WebDriver driver = new RemoteWebDriver(new URL(URL), caps);

	    /**
	    * Goes to Sauce Lab's guinea-pig page and prints title
	    */

	    driver.get("https://saucelabs.com/test/guinea-pig");
	    System.out.println("title of page is: " + driver.getTitle());

	    driver.quit();
	  }
	}


