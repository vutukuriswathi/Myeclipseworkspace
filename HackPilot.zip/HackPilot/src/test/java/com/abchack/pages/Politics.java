package com.abchack.pages;

public class Politics {

}
